package com.nhktech.whatifbackground

import android.app.Notification
import android.app.NotificationChannel
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

class RenderKeepAliveService : Service() {
    override fun onCreate() {
        super.onCreate()
        val id = "renderer_session"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(android.app.NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(id, "Renderer session", android.app.NotificationManager.IMPORTANCE_LOW))
        }
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, id) else Notification.Builder(this)
        val note = builder.setContentTitle("What If Renderer is active")
            .setContentText("Keep the renderer visible in its small floating window.")
            .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build()
        startForeground(781, note)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
}
