package com.nhktech.whatifbackground

import android.app.DownloadManager
import android.app.PictureInPictureParams
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.util.Rational
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private var blobFile: File? = null
    private var blobName: String = "rendered-video.mp4"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(TextView(this).apply {
            text = "WHAT IF RENDERER — keep this small window visible while using other apps"
            textSize = 14f
            setPadding(12, 10, 12, 8)
        })
        val row = LinearLayout(this)
        row.addView(Button(this).apply { text = "Enter small window"; setOnClickListener { enterPip() } })
        row.addView(Button(this).apply { text = "Reload"; setOnClickListener { web.reload() } })
        root.addView(row)
        status = TextView(this).apply {
            text = "Ready. Completed video downloads will be saved in Downloads/WhatIfRenderer."
            textSize = 12f
            setPadding(12, 6, 12, 6)
        }
        root.addView(status)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = true
            webChromeClient = WebChromeClient()
            addJavascriptInterface(BlobDownloadBridge(), "AndroidDownload")
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    view.evaluateJavascript(BLOB_DOWNLOAD_SCRIPT, null)
                }
            }
            setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                if (url.startsWith("blob:")) {
                    runOnUiThread { status.text = "Preparing video download…" }
                } else {
                    downloadHttpFile(url, userAgent, contentDisposition, mimeType)
                }
            })
            loadUrl("http://127.0.0.1:8781")
        }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        val service = Intent(this, RenderKeepAliveService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
    }

    private fun downloadHttpFile(url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        try {
            val request = DownloadManager.Request(Uri.parse(url))
            request.setTitle("Renderer video")
            request.setDescription("Downloading completed render")
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "WhatIfRenderer/${safeFileName(contentDisposition, url)}")
            request.setMimeType(mimeType ?: "application/octet-stream")
            request.addRequestHeader("User-Agent", userAgent ?: "")
            CookieManager.getInstance().getCookie(url)?.let { request.addRequestHeader("Cookie", it) }
            val manager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            status.text = "Download started. Check Downloads/WhatIfRenderer."
        } catch (e: Exception) {
            status.text = "Download failed: ${e.message}"
        }
    }

    private fun safeFileName(disposition: String?, url: String): String {
        val fromHeader = disposition?.substringAfter("filename=", "")?.trim('"', '\'')
        val fromUrl = Uri.parse(url).lastPathSegment
        val raw = fromHeader?.takeIf { it.isNotBlank() } ?: fromUrl?.takeIf { it.isNotBlank() } ?: "rendered-video.mp4"
        return raw.replace(Regex("[^A-Za-z0-9._-]"), "_").take(120)
    }

    private inner class BlobDownloadBridge {
        @JavascriptInterface fun begin(name: String) {
            try {
                blobName = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(120).ifBlank { "rendered-video.mp4" }
                blobFile = File(cacheDir, "blob-download-${System.currentTimeMillis()}.tmp")
                blobFile!!.writeBytes(ByteArray(0))
                runOnUiThread { status.text = "Preparing $blobName…" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Could not prepare download: ${e.message}" }
            }
        }
        @JavascriptInterface fun append(chunkBase64: String) {
            try {
                val bytes = Base64.decode(chunkBase64, Base64.DEFAULT)
                val target = blobFile ?: return
                FileOutputStream(target, true).use { it.write(bytes) }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Video transfer failed: ${e.message}" }
            }
        }
        @JavascriptInterface fun finish(mime: String) {
            runOnUiThread {
                val source = blobFile
                if (source == null || !source.exists()) {
                    status.text = "No video data received."
                    return@runOnUiThread
                }
                try {
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, blobName)
                        put(MediaStore.MediaColumns.MIME_TYPE, mime.ifBlank { "video/mp4" })
                        if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/WhatIfRenderer")
                    }
                    val resolver = contentResolver
                    val collection = if (Build.VERSION.SDK_INT >= 29) MediaStore.Downloads.EXTERNAL_CONTENT_URI else MediaStore.Files.getContentUri("external")
                    val uri = resolver.insert(collection, values) ?: throw Exception("Android could not create the download file")
                    resolver.openOutputStream(uri)?.use { output -> source.inputStream().use { it.copyTo(output) } }
                        ?: throw Exception("Could not write the downloaded video")
                    source.delete()
                    blobFile = null
                    status.text = "Saved: Downloads/WhatIfRenderer/$blobName"
                    Toast.makeText(this@MainActivity, "Video saved to Downloads/WhatIfRenderer", Toast.LENGTH_LONG).show()
                } catch (e: Exception) { status.text = "Could not save video: ${e.message}" }
            }
        }
        @JavascriptInterface fun failed(message: String) {
            runOnUiThread { status.text = "Video download failed: $message" }
        }
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= 26) {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
        }
    }
    override fun onUserLeaveHint() { super.onUserLeaveHint(); enterPip() }
    override fun onDestroy() {
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }

    companion object {
        private const val BLOB_DOWNLOAD_SCRIPT = """
        (function() {
          if (window.__androidBlobDownloadInstalled) return;
          window.__androidBlobDownloadInstalled = true;
          document.addEventListener('click', function(event) {
            var link = event.target && event.target.closest ? event.target.closest('a') : null;
            if (!link || !link.href || !link.href.startsWith('blob:')) return;
            event.preventDefault(); event.stopImmediatePropagation();
            var name = link.getAttribute('download') || 'rendered-video.mp4';
            fetch(link.href).then(function(r) { return r.blob(); }).then(async function(blob) {
              AndroidDownload.begin(name);
              var chunkSize = 512 * 1024;
              for (var offset = 0; offset < blob.size; offset += chunkSize) {
                var part = await blob.slice(offset, Math.min(offset + chunkSize, blob.size)).arrayBuffer();
                var bytes = new Uint8Array(part), binary = '';
                for (var i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
                AndroidDownload.append(btoa(binary));
              }
              AndroidDownload.finish(blob.type || 'video/mp4');
            }).catch(function(e) { AndroidDownload.failed(String(e)); });
          }, true);
        })();
        """
    }
}
