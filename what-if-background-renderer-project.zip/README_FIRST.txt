WHAT IF BACKGROUND RENDERER — EXPERIMENTAL APK

This app is a small test wrapper for the local renderer at:
http://127.0.0.1:8781

IMPORTANT
- Start your existing renderer in Termux first.
- Open this app while the renderer server is running.
- The app loads the local renderer in Android WebView.
- The app can enter Picture-in-Picture (a small floating window).
- This is experimental. Android may still pause or throttle WebView/WebGL rendering in PiP or while another app is active. It is not a guarantee of background rendering.
- This does not replace, edit, or delete your existing renderer project.

BUILD
The GitHub Actions workflow builds a debug APK and uploads it as an artifact.
