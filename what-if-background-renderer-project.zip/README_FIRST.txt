WHAT IF BACKGROUND RENDERER — PROTOTYPE 0.1

This is an experimental test app. It opens your existing local renderer at:
http://127.0.0.1:8781

It adds a foreground notification and Picture-in-Picture (a small floating window).
The goal is to keep the renderer visibly on screen while you use WhatsApp.

IMPORTANT: This is NOT a proven fix. Android may still throttle WebView/WebGL,
especially if the phone is locked or the floating window is hidden. The service
helps keep the app process alive; it cannot guarantee continuous rendering.

BUILD THE APK
1. Open your private repository:
   https://github.com/Nhktech/what-if-background-renderer
2. Choose Add file > Upload files.
3. Upload the CONTENTS of this ZIP (not the ZIP itself).
4. Commit to the main branch.
5. Open Actions and wait for "Build Android APK" to finish.
6. Open the completed run, scroll to Artifacts, and download
   what-if-background-renderer-debug.
7. Extract that downloaded ZIP and install app-debug.apk.

TEST
1. Start your existing Termux Video Renderer shortcut.
2. Confirm http://localhost:8781 works in Chrome.
3. Open this app; it loads the same local renderer.
4. Start a render.
5. Switch to WhatsApp. The app should shrink into a small floating window.
6. Check whether the progress continues.

CURRENT SCOPE
This first prototype only tests whether the local renderer WebView keeps working
in Picture-in-Picture. It does not replace your current renderer or move TSX files.
Keep your existing project and backup unchanged.
